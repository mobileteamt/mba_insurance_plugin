<?php
/**
 * Plugin Name: Synapse India Support
 * Plugin URI:  https://www.synapseindia.com/
 * Description: WordPress API functions.
 * Version:     1.1.1
 * Author:      SynapseIndia Outsourcing Pvt. Ltd.
 * Author URI:  https://www.synapseindia.com/
 * License:     GPL-3.0
 * Text Domain: sy-support
 *
 */

defined( 'ABSPATH' ) || die( "Can't access directly" );

// Helper constants.
define( 'SYI_PLUGIN_DIR', rtrim( plugin_dir_path( __FILE__ ), '/' ) );
define( 'SYI_PLUGIN_URL', rtrim( plugin_dir_url( __FILE__ ), '/' ) );
define( 'SYI_PLUGIN_VERSION', '1.1.1' );
define( 'SYI_NAMESSPACE', 'rvapi/v1' );
define( 'REALTEO_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

require_once(__DIR__ . '/vendor/autoload.php');
require_once(__DIR__ . '/sycustom/apis/functions.php');
require_once(__DIR__ . '/sycustom/CoreUser.php');

use Sycustom\api\Base;
use Sycustom\onfido\Init;
use Sycustom\mbains\MBAInit;

new Base();
new Init();
new MBAInit();


//add_action( 'admin_enqueue_scripts', 'si_add_admin_style' );
add_action( 'wp_enqueue_scripts', 'si_add_frontEnd_assets' );

function si_add_frontEnd_assets() {
  wp_enqueue_style( 'si_frontent_style', plugins_url( '/assets/css/sysupport.css', __FILE__ ), false );
  wp_register_script( 'si_frontent_asset', plugins_url( '/assets/js/sysupport.js', __FILE__ ), array( 'jquery' ), '1.0.0', true);
  $wnm_custom  =  array( 
            'ajax_uri'         => admin_url( 'admin-ajax.php' )
            );
  wp_localize_script( 'si_frontent_asset', 'siscript', $wnm_custom );
  wp_enqueue_script( 'si_frontent_asset' );
}

function si_add_admin_style() {
  wp_enqueue_style( 'si_frontent_style', plugins_url( '/assets/css/sysupport.css',  __FILE__ ), false );
  wp_register_script( 'si_frontent_asset', plugins_url( '/assets/js/sysupport.js',  __FILE__ ), array( 'jquery' ), '1.0.0', true);
  $wnm_custom  =  array( 
            'ajax_uri'         => admin_url( 'admin-ajax.php' )
            );
  wp_localize_script( 'si_frontent_asset', 'siscript', $wnm_custom );
  wp_enqueue_script( 'si_frontent_asset' );
}

