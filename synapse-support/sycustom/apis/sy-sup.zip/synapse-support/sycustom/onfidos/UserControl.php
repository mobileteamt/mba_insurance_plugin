<?php

namespace Sycustom\onfido;

class UserControl{
	public function __construct(){
		//add_action('wp_footer', [$this, 'add_custom_hook']);
		//add_filter( 'registration_redirect', [$this,'my_redirect_home'], 30, 2 );
	}

	/*public function add_custom_hook(){
		echo 'synapse';
	}*/
	
	
	/*public function my_redirect_home(  ) {
		return home_url("/my-profile/");
	}*/
}
