<?php

namespace Sycustom\mbains;
use Sycustom\mbains\WooReplacement;

class Init{
	public function __construct(){
		
	}

	public function set_default_customer( $user_id, $userdata ){
		
	}
}
