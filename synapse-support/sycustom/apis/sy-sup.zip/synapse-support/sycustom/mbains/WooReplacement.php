<?php
namespace Sycustom\mbains;

class WooReplacement{
	public function __construct(){
		
	}

}
